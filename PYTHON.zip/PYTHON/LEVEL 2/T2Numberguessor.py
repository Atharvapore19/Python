import random

def number_guesser():
    print("Welcome to the Number Guessing Game!")
    
    # Prompt the user to specify the range
    lower_bound = int(input("Enter the lower bound of the range: "))
    upper_bound = int(input("Enter the upper bound of the range: "))
        number_to_guess = random.randint(lower_bound, upper_bound)
    attempts = 0

    print(f"I have generated a number between {lower_bound} and {upper_bound}. Try to guess it!")

    while True:
        # Take the user's guess
        guess = int(input("Enter your guess: "))
        attempts += 1
        if guess < number_to_guess:
            print("Too low! Try again.")
        elif guess > number_to_guess:
            print("Too high! Try again.")
        else:
            print(f"Congratulations! You guessed the correct number {number_to_guess} in {attempts} attempts.")
            break
number_guesser()
