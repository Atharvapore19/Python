import re
from collections import defaultdict

def count_words_in_file(file_path):
    word_counts = defaultdict(int)
    
    # Read the file and count the occurrences of each word
    with open(file_path, 'r') as file:
        for line in file:
            # Remove punctuation and convert to lowercase
            words = re.findall(r'\b\w+\b', line.lower())
            for word in words:
                word_counts[word] += 1

    # Sort the words alphabetically and display their counts
    for word in sorted(word_counts):
        print(f"{word}: {word_counts[word]}")

def main():
    file_path = input("Enter the path to the text file: ")
    try:
        count_words_in_file(file_path)
    except FileNotFoundError:
        print("File not found. Please enter a valid file path.")

# Example usage:
main()
