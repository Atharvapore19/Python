import re

def password_strength(password):
    length_criteria = len(password) >= 8
    
    uppercase_criteria = re.search(r'[A-Z]', password) is not None
    
    lowercase_criteria = re.search(r'[a-z]', password) is not None
    
    digit_criteria = re.search(r'\d', password) is not None
    
    special_char_criteria = re.search(r'[!@#$%^&*(),.?":{}|<>]', password) is not None
    
    strength = {
        "Length (8+ characters)": length_criteria,
        "Uppercase Letter": uppercase_criteria,
        "Lowercase Letter": lowercase_criteria,
        "Digit": digit_criteria,
        "Special Character": special_char_criteria
    }
    
    return strength

def check_password_strength():
    password = input("Enter a password to check its strength: ")
    strength = password_strength(password)
    
    print("\nPassword Strength Criteria:")
    for criteria, passed in strength.items():
        print(f"{criteria}: {'Passed' if passed else 'Failed'}")
    
    if all(strength.values()):
        print("\nYour password is strong!")
    else:
        print("\nYour password is not strong enough. Consider the criteria above to improve it.")
check_password_strength()
