import os
import string
import joblib
import pandas as pd
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from nltk.corpus import stopwords

# Ensure NLTK stopwords are downloaded
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# Create models folder if not exists
os.makedirs("models", exist_ok=True)

# Preprocess text (removing punctuation & stopwords, lowercasing)
def preprocess_text(text):
    text = ''.join([char for char in text if char not in string.punctuation])
    return ' '.join([word.lower() for word in text.split() if word.lower() not in stop_words])

# Load Dataset
file_path = 'data/Twitter_Bot_Detection_Realistic_Dataset.xlsx'
df = pd.read_excel(file_path)

# Ensure dataset columns are valid (adjust if your column names differ)
assert 'Tweet Text' in df.columns, "Column 'Tweet Text' not found in dataset"
assert 'Bot Status' in df.columns, "Column 'Bot Status' not found in dataset"
assert 'Sentiment Label' in df.columns, "Column 'Sentiment Label' not found in dataset"
assert 'Abusive Content Flag' in df.columns, "Column 'Abusive Content Flag' not found in dataset"

# Preprocess all tweets
df['Cleaned_Text'] = df['Tweet Text'].apply(preprocess_text)

# Features and labels
X = df['Cleaned_Text']
y_bot = df['Bot Status']
y_sentiment = df['Sentiment Label']
y_abusive = df['Abusive Content Flag']

# Split data into training and test sets
X_train_bot, X_test_bot, y_train_bot, y_test_bot = train_test_split(X, y_bot, test_size=0.2, random_state=42)
X_train_sent, X_test_sent, y_train_sent, y_test_sent = train_test_split(X, y_sentiment, test_size=0.2, random_state=42)
X_train_abusive, X_test_abusive, y_train_abusive, y_test_abusive = train_test_split(X, y_abusive, test_size=0.2, random_state=42)

# Define Model Pipelines
def create_pipeline():
    return Pipeline([
        ('tfidf', TfidfVectorizer()),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])

# Train Models
bot_model = create_pipeline()
bot_model.fit(X_train_bot, y_train_bot)

sentiment_model = create_pipeline()
sentiment_model.fit(X_train_sent, y_train_sent)

abusive_model = create_pipeline()
abusive_model.fit(X_train_abusive, y_train_abusive)

# Save Models
joblib.dump(bot_model, 'models/bot_model.pkl')
joblib.dump(sentiment_model, 'models/sentiment_model.pkl')
joblib.dump(abusive_model, 'models/abusive_model.pkl')

print("✅ All models have been trained and saved to the 'models/' directory successfully!")
