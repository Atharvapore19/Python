DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'tiger',
    'database': 'twitter_bot_detection'
}
