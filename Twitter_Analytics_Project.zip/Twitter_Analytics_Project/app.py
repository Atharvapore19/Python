import string
import datetime
import random
import pandas as pd
import mysql.connector
import networkx as nx
from flask import Flask, render_template, request
import joblib
import nltk
from nltk.corpus import stopwords
from config import DB_CONFIG

nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

app = Flask(__name__)

# Load models
bot_model = joblib.load('models/bot_model.pkl')
sentiment_model = joblib.load('models/sentiment_model.pkl')
abusive_model = joblib.load('models/abusive_model.pkl')


def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)


def preprocess_text(text):
    text = ''.join([char for char in text if char not in string.punctuation])
    return ' '.join([word.lower() for word in text.split() if word.lower() not in stop_words])


def get_emerging_trends():
    return [
        {"topic": "AI Regulation", "mentions": random.randint(100, 500)},
        {"topic": "SpaceX Launch", "mentions": random.randint(100, 500)},
        {"topic": "New Cyber Law", "mentions": random.randint(100, 500)}
    ]


def get_influencer_impact():
    graph = nx.erdos_renyi_graph(10, 0.5)
    influence_scores = {f"User_{i}": nx.degree_centrality(graph)[i] for i in range(len(graph))}
    return influence_scores


@app.route('/')
def home():
    return render_template('index.html', trends=[], influencers={}, tweet="", show_add_form=False)


@app.route('/predict', methods=['POST'])
def predict():
    tweet = request.form['tweet']
    cleaned_tweet = preprocess_text(tweet)

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM bot_data WHERE LOWER(`Tweet Text`) = %s", (tweet.lower(),))
    tweet_data = cursor.fetchone()

    if tweet_data:
        bot_prediction = bot_model.predict([cleaned_tweet])[0]
        sentiment = sentiment_model.predict([cleaned_tweet])[0]
        abusive_prediction = abusive_model.predict([cleaned_tweet])[0]

        bot_status = 'Bot' if bot_prediction == 1 else 'Human'
        abusive_status = 'Abusive' if abusive_prediction == 1 else 'Non-Abusive'

        return render_template('index.html',
                               tweet=tweet,
                               bot_status=bot_status,
                               sentiment=sentiment,
                               abusive_status=abusive_status,
                               tweet_data=tweet_data,
                               trends=get_emerging_trends(),
                               influencers=get_influencer_impact())
    else:
        return render_template('index.html',
                               error="Tweet not found! Please provide the additional details to store this tweet.",
                               tweet=tweet,
                               show_add_form=True,
                               trends=[], influencers={})


@app.route('/add_tweet', methods=['POST'])
def add_tweet():
    tweet = request.form['tweet']
    username = request.form['username']
    followers = request.form['followers']
    following = request.form['following']
    likes = request.form['likes']
    reposts = request.form['reposts']
    tweet_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    INSERT INTO bot_data (`Tweet Text`, Username, Followers, Following, `Number of Likes`, `Number of Reposts`, `Time of Account Creation`)
    VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (tweet, username, followers, following, likes, reposts, tweet_time))
    conn.commit()

    return render_template('index.html', 
                           message="Tweet stored successfully! Now re-enter the tweet and analyze it.",
                           trends=[], influencers={}, tweet="")


if __name__ == '__main__':
    app.run(debug=True)
